import java.util.*;
public class BUCKET_PROBLEM {
    public static void main(String args[]){
        Scanner scan=new Scanner(System.in);
        int n=scan.nextInt();
        String s=Integer.toHexString(n);
        System.out.println(s.toUpperCase());
    }
}
