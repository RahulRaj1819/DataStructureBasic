import java.util.*;
public class Nth_NUMBER_DIV_BY_a_or_B {
    public static void main(String args[]){
        Scanner scan=new Scanner(System.in);
        int t=scan.nextInt();
        while(t!=0){
            long a=scan.nextLong();
            long b=scan.nextLong();
            long n=scan.nextLong();
            long i,j,k, count=0;
            if(a>b){
               j=a;
               i=b;
               
            }
            else{
                i=a;
               
                j=b;
            }
            int arr1[]=new int[]
            while(true)  {
                if(count==n){
                    
                }
            }            
                
            t--;
        }
    }
}
